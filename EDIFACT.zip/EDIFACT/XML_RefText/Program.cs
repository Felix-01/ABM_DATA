﻿using System;
using System.Linq;
using System.Xml.Linq;

namespace XML_RefText
{
    class Program
    {
        /// <summary>
        /// The below code is written to extract the following RefCodes: 'MWB', 'TRV' and 'CAR'
        /// which are elements of a given xml document and the values of the corresponding attributes, RefText.
        /// </summary>
        private static string path = @"C:\Users\Felix\source\repos\EDIFACT\XML_RefText\XMLFile1.xml";

        static void Main(string[] args)
        {
                                 
            //Load xml
            XDocument testXML = XDocument.Load(path);
                var students = from student in testXML.Descendants("Reference")
                                select new
                                {
                                    RefCode = student.Attribute("RefCode").Value,
                                    RefText = student.Element("RefText").Value 
                                };
 
                foreach (var student in students)
                {
                    if(student.RefCode == "MWB" || student.RefCode == "TRV" || student.RefCode == "CAR")
                    {
                        Console.WriteLine($"RefCode: {student.RefCode}, RefText: {student.RefText}"); 
                    }
                }            
            
            Console.ReadLine();
        }
    }
}
