﻿using System;
using System.Collections.Generic;

namespace EDIFACT
{
    class Segment
    {
        public string SegmentName { get; set; }
        public string[] ElementValue { get; set; }

        /// <summary>
        /// This method takes in an EDI message as a string and splits it into segments.
        /// It then extracts the segments of interest, splits them into sub-segments and retrieves required values.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="delimiter"></param>
        /// <returns></returns>
        public List<Segment> SplitString(string message, string delimiter)
        {
             List<Segment> listOfSegments = new List<Segment>();

            message = message.Replace("\r\n", string.Empty);
            string[] segments = message.Split(delimiter, StringSplitOptions.RemoveEmptyEntries);

            foreach (var segment in segments)
            {              
                
                if(segment.Trim().Substring(0, 3) == "LOC")
                {
                    Segment sgmnt = new Segment();
                    string[] elements = segment.Split("+");
                    sgmnt.SegmentName = elements[0];

                    sgmnt.ElementValue = new string [elements.Length - 1];
                    for (int i = 0; i < elements.Length-1; i++)
                    {
                        sgmnt.ElementValue[i] = elements[i+1];
                    }
                    
                    listOfSegments.Add(sgmnt);
                }

            }
            return listOfSegments;
        }
    }
}
