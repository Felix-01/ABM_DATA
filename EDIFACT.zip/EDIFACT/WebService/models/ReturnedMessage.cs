﻿namespace WebService.models
{
    public class ReturnedMessage
    {
        public int Status { get; set; }
        public string Message { get; set; }
    }
}
