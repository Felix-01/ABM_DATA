﻿using System.IO;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using WebService.models;
using WebService.Service;

namespace WebService.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValidationController : ControllerBase
    {
        /// <summary>
        /// The validation controller receives the data from "Postman" or similar, 
        /// as xml text and puts it in an instance of StreamReader. The Validator
        /// method consumes the file directly from the StreamReader, and returns
        /// a status and a message.
        /// </summary>
        /// <returns></returns>
        // POST: api/Validation
        [HttpPost]
        public string Post()
        {           
            ReturnedMessage rtm = new ReturnedMessage();
            
            using (StreamReader reader = new StreamReader(Request.Body, Encoding.UTF8))
            {                
                Validate validate = new Validate();
                validate.Validator(reader, out int status, out string message);
                
                rtm.Status = status;
                rtm.Message = message;
            }
            return  string.Format($"Status: {rtm.Status.ToString()}  {rtm.Message}");
        }        
    }
}
