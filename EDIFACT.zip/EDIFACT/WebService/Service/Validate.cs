﻿using System.IO;
using System.Linq;
using System.Xml.Linq;
using System.Xml.Schema;

namespace WebService.Service
{
    public class Validate
    {
        /// <summary>
        /// First, a schema was created from the xml document provided 
        /// using the resources at http://xmlgrid.net/xml2xsd.html.
        /// The document to be validated is passed in from the controller.        /// 
        /// </summary>
        /// <param name="xmlfile"></param>
        /// <param name="status"></param>
        /// <param name="message"></param>
        public void Validator(StreamReader xmlfile, out int status, out string message)
        {
            int statusCode = 0;
            string reason = "";

            XmlSchemaSet schema = new XmlSchemaSet();

            schema.Add("", @"C:\Users\Felix\source\repos\EDIFACT\WebService\InputDocument.xsd");

            XDocument xdoc = XDocument.Load(xmlfile);

            bool validationErrors = false;
            xdoc.Validate(schema, (s, e) =>
            {
                reason = e.Message;
                validationErrors = true;
            });
            if (!validationErrors)
            {
                statusCode = 0;
                reason = "Document structured correctly";
            }
            else if (validationErrors)
            {
                statusCode = -3;
                reason = "Document structured incorrectly";
            }
            
            var elem = from element in xdoc.Descendants("Declaration")
                       select element;
            
            foreach (var doc in elem)
            {
                if (doc.Attribute("Command").Value != "DEFAULT")
                {
                    statusCode = -1;
                    reason = "Invalid 'Command' specified";
                }                
            }
            var elem2 = from element in xdoc.Descendants("DeclarationHeader")
                        select element;

            foreach (var item in elem2)
            {
                if (item.Element("SiteID").Value != "DUB")
                {
                    statusCode = -2;
                    reason = "Invalid 'Site' specified";
                }                
            }
            status = statusCode;
            message = reason;
        }        
    }
}
